package com.tictactoe.snakegame;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class SnakeGame extends JFrame {

    public SnakeGame() {

        setTitle("Snake Game");
        setSize(600, 600);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        GamePanel gamePanel = new GamePanel();
        add(gamePanel);

        setVisible(true);

        
        gamePanel.requestFocusInWindow();
    }

    public static void main(String[] args) {
        new SnakeGame();
    }
}




class GamePanel extends JPanel implements ActionListener, KeyListener {

    
    final int GAME_WIDTH = 600;
    final int GAME_HEIGHT = 600;

    
    int[] snakeX = new int[100];
    int[] snakeY = new int[100];

    int bodyParts = 4;

    
    int unitSize = 20;
    char direction = 'R';

    
    Timer timer;


    

    public GamePanel() {

        setBackground(Color.BLACK);

        setFocusable(true);
        addKeyListener(this);

        
        snakeX[0] = 300;
        snakeY[0] = 300;

        snakeX[1] = 280;
        snakeY[1] = 300;

        snakeX[2] = 260;
        snakeY[2] = 300;

        snakeX[3] = 240;
        snakeY[3] = 300;

        
        timer = new Timer(150, this);
        timer.start();
    }


    

    public void moveSnake() {

       
        for (int i = bodyParts - 1; i > 0; i--) {

            snakeX[i] = snakeX[i - 1];
            snakeY[i] = snakeY[i - 1];
        }

        
        if (direction == 'U') {
            snakeY[0] = snakeY[0] - unitSize;
        }

        if (direction == 'D') {
            snakeY[0] = snakeY[0] + unitSize;
        }

        if (direction == 'L') {
            snakeX[0] = snakeX[0] - unitSize;
        }

        if (direction == 'R') {
            snakeX[0] = snakeX[0] + unitSize;
        }

        
        if (snakeX[0] < 0) {
            snakeX[0] = GAME_WIDTH - unitSize;
        }

        if (snakeX[0] >= GAME_WIDTH) {
            snakeX[0] = 0;
        }

        if (snakeY[0] < 0) {
            snakeY[0] = GAME_HEIGHT - unitSize;
        }

        if (snakeY[0] >= GAME_HEIGHT) {
            snakeY[0] = 0;
        }
    }


    

    @Override
    protected void paintComponent(Graphics g) {

        super.paintComponent(g);

        
        for (int i = 0; i < bodyParts; i++) {

            if (i == 0) {
                
                g.setColor(Color.RED);
            } else {
                
                g.setColor(Color.WHITE);
            }

            g.fillRect(
                    snakeX[i],
                    snakeY[i],
                    unitSize,
                    unitSize
            );
        }
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {

        moveSnake();

        repaint();
    }


    

    @Override
    public void keyPressed(KeyEvent e) {

        
        if (e.getKeyCode() == KeyEvent.VK_UP) {

            
            if (direction != 'D') {
                direction = 'U';
            }
        }


        
        if (e.getKeyCode() == KeyEvent.VK_DOWN) {

            if (direction != 'U') {
                direction = 'D';
            }
        }


        
        if (e.getKeyCode() == KeyEvent.VK_LEFT) {

            if (direction != 'R') {
                direction = 'L';
            }
        }


        
        if (e.getKeyCode() == KeyEvent.VK_RIGHT) {

            if (direction != 'L') {
                direction = 'R';
            }
        }
    }


    @Override
    public void keyReleased(KeyEvent e) {
        
    }


    @Override
    public void keyTyped(KeyEvent e) {
        
    }
}